edad =0

edad=input("Ingrese su edad:")

if int(edad)>18:
    print("Usted es mayor de edad")
else:
    print("Usted no es mayor de edad")
    

